Su Gold AI Trading — Full Android-first prototype

Included:
- Responsive dashboard and embedded TradingView OANDA:XAUUSD chart with M5/M15/H1/H4/D1 timeframe selection.
- Best-effort free public spot gold quote request (may fail because of provider/CORS/network changes; not guaranteed real-time and can differ from broker quote).
- ICT/SMC rule-based heuristic analyzer using imported OHLC CSV candles; local-only analysis.
- Risk calculator (educational estimate; broker contract specs vary).
- Trading journal saved in this browser's local storage, with CSV export.
- Settings for timeframe, balance, and risk percentage.

How to use:
1. Extract the ZIP on Android.
2. Open index.html in a browser. If local file restrictions block external chart or quote requests, host the files on a static HTTPS host (e.g. GitHub Pages).
3. Import OHLC CSV for the ICT/SMC analyzer (at least 30 rows with open, high, low, close columns).
4. Verify every result on your broker's chart and use Demo for practice.

Limitations:
- This is a prototype, not an AI prediction model.
- It does not read chart candles directly from TradingView.
- No automatic continuous signal generation, broker login, MT5 connection, or order execution.
- Free quote source availability is not guaranteed; chart/quote can be delayed or differ from broker.
- Journal data stays in this browser/device and may be lost if browser storage is cleared.
- Risk calculation depends on the assumed dollar P/L per $1 move at 1.00 lot. Check your broker's XAUUSD contract specification.
- No profit guarantee. Educational use only.


## Signal Center update
The dashboard now includes a Signal Center showing the latest rule-based BUY/SELL setup candidate or WAIT, with illustrative entry reference, stop-loss and take-profit levels after OHLC CSV analysis. Signals only update when candles are analyzed; this is not an automatic live signal feed and does not place trades.
